package bgu.spl.net.impl.stomp;

import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import bgu.spl.net.api.StompMessagingProtocol;
import bgu.spl.net.impl.data.Database;
import bgu.spl.net.impl.data.LoginStatus;
import bgu.spl.net.srv.Connections;


public class StompProtocol implements StompMessagingProtocol<StompFrame> {

    private boolean shouldTerminate = false;
    private int connectionId = -1;
    private Connections<StompFrame> connections;
    private static final AtomicInteger MessageIdCounter = new AtomicInteger(0);
    private boolean loggedIn = false;
    private final Database database = Database.getInstance();
    private String currentUser = null;



    @Override
    public void start(int connectionId, Connections<StompFrame> connections) {
        this.connectionId = connectionId;
        this.connections = connections; 
    }
    

    @Override
    public void process(StompFrame message) {
        StompFrame.Header receiptHeader = message.getReceipt();
        StompFrame receipt = null; 
        if (receiptHeader != null) 
            receipt = generateReceipt(receiptHeader);   

        if (message.getType() == FrameType.DISCONNECT) {

            System.out.println("SERVER DISCONNECT receipt=" +
                        (receiptHeader == null ? "null" : receiptHeader.getValue()));

            if (receiptHeader == null) {
                terminate(null, "didn't provide receipt-id for DISCONNECT", "");
                return;
            }

            loggedIn = false;
            database.logout(connectionId);
            connections.send(connectionId, receipt);
            connections.disconnect(connectionId);
            shouldTerminate = true;
            return;
        }
        else if (message.getType() == FrameType.SEND) { // we need to send MESSAGE to all of the subs in the channel
            if (!loggedIn) {
                terminate(receiptHeader, "User is not logged in", "");
                return;
            }

            String dest = message.getHeaderValue("destination");
            if(dest == null || dest.isEmpty()) {
                terminate(receiptHeader, "No destination provided", "");  
                return; 
            }
            
                
            ConcurrentHashMap<Integer, String> subscribers = connections.getSubscribers(dest);

            if(subscribers.isEmpty() || connections.getSubscriptionId(connectionId, dest) == null) {
                terminate(receiptHeader, "The user is not subscribed to the channel", "");
                return;
            }


            String filename = message.getHeaderValue("filename");
            if (filename == null || filename.isEmpty()) {
                filename = "REPORT";
            }

            String gameChannel = dest.replaceFirst("^/topic/", "");

            database.trackFileUpload(currentUser, filename, gameChannel);
                
            int msgId = MessageIdCounter.getAndIncrement();

            for(Integer clientId : subscribers.keySet()){
                String subscriberId = subscribers.get(clientId);

                Vector<StompFrame.Header> headers = new Vector<>();
                headers.add(new StompFrame.Header("subscription", subscriberId));
                headers.add(new StompFrame.Header("message-id", String.valueOf(msgId)));
                headers.add(new StompFrame.Header("destination", dest));
            
                StompFrame frame = new StompFrame(FrameType.MESSAGE, message.getBody(), headers);

                try {
                    connections.send(clientId, frame);
                } catch(Exception e) {
                    terminate(receiptHeader, "Couldn't send the message to one or more subscribers", "");
                    return;
                }
            }
        }
        else if (message.getType() == FrameType.CONNECT) {

            String login = message.getHeaderValue("login");
            String passcode = message.getHeaderValue("passcode");

            if (login == null || passcode == null) {
                connections.send(connectionId,
                    generateError(null, "Missing login or passcode", ""));
                return;
            }

            LoginStatus status = database.login(connectionId, login, passcode);

            switch (status) {
                case CLIENT_ALREADY_CONNECTED:
                    connections.send(connectionId,
                        generateError(null, "Client already connected", ""));
                    return;

                case WRONG_PASSWORD:
                    connections.send(connectionId,
                        generateError(null, "Wrong password", ""));
                    return;

                case ALREADY_LOGGED_IN:
                    connections.send(connectionId,
                        generateError(null, "User already logged in", ""));
                    return;

                case ADDED_NEW_USER:
                case LOGGED_IN_SUCCESSFULLY:
                    loggedIn = true;
                    currentUser = login;

                    Vector<StompFrame.Header> headers = new Vector<>();
                    headers.add(new StompFrame.Header("version", "1.2"));

                    connections.send(connectionId, new StompFrame(FrameType.CONNECTED, "", headers));
                return;
            }

        }
        else if (message.getType() == FrameType.SUBSCRIBE) {
            // Handle SUBSCRIBE frame
            String dest = message.getHeaderValue ("destination");
            String subscriberId = message.getHeaderValue ("id");
            if(dest == null || dest.isEmpty() || subscriberId == null || subscriberId.isEmpty()) {
                terminate(receiptHeader, "Wrong format for SUBSCRIBE", "");
                return;
            }
                
            connections.subscribe(connectionId, dest, subscriberId);

        }
        else if (message.getType() == FrameType.UNSUBSCRIBE) {
            // Handle UNSUBSCRIBE frame
            String subId = message.getHeaderValue("id");
            if (subId == null || subId.isEmpty()) 
                return;

            String dest = connections.getDestinationBySubId(connectionId, subId);
            if (dest == null || dest.isEmpty()) {
                terminate(receiptHeader, "Wrong format for UNSUBSCRIBE", "");
                return;
            }
            connections.unsubscribe(connectionId, dest);
        }

        // Send receipt at the end if one was requested and we didn't already send an error
        if (!shouldTerminate && receipt != null) {
            connections.send(connectionId, receipt);
        }
    }

	/**
     * @return true if the connection should be terminated
     */
    @Override
    public boolean shouldTerminate() {
        return shouldTerminate;
    }

    private void terminate(StompFrame.Header source, String message, String body) {
        connections.send(connectionId, generateError(source, message, body));
        //connections.disconnect(connectionId);
        //shouldTerminate = true;
        //loggedIn = false;

        // if this connection was logged in, make sure DB state is cleaned
        if (loggedIn) {
            database.logout(connectionId);
            loggedIn = false;
            currentUser = null;
        }

        // STOMP ERROR should close the connection
        connections.disconnect(connectionId);
        shouldTerminate = true;
    }

    //HELPERS

    private StompFrame generateReceipt(int id) {
        Vector<StompFrame.Header> headers = new Vector<StompFrame.Header>();
        headers.add(new StompFrame.Header("receipt-id", Integer.toString(id)));


        return new StompFrame(FrameType.RECEIPT, "", headers);
    }

    private StompFrame generateReceipt(StompFrame.Header source) {
    Vector<StompFrame.Header> headers = new Vector<>();
    headers.add(new StompFrame.Header(
        "receipt-id",
        source.getValue()
    ));
    return new StompFrame(FrameType.RECEIPT, "", headers);
    }

    private StompFrame generateError(StompFrame.Header source, String message, String body) {
        Vector<StompFrame.Header> headers = new Vector<>();
        if (source != null) {
            headers.add(source);
        }
        StompFrame.Header msgHeader = new StompFrame.Header("message", message);
        headers.add(msgHeader);

        if (body == null) {
            body = "";
        }

        return new StompFrame(FrameType.ERROR, body, headers);
    }
}
